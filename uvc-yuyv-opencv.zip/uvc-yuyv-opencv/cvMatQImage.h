#ifndef CVMATQIMAGE_H
#define CVMATQIMAGE_H
#include <QImage>
#include <cv.h>
#include <highgui.h>
#include <imgproc/imgproc.hpp>
using namespace cv;


QImage cvMat2QImage(const cv::Mat& mat);
cv::Mat QImage2cvMat(QImage image);
#endif
