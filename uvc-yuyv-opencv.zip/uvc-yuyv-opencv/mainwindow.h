#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QPainter>
#include <QMessageBox>
#include <QTimer>
#include <QHBoxLayout>
#include <QDebug>
#include "videodevice.h"
#include "cvMatQImage.h"

#include <cv.h>
#include <highgui.h>
using namespace cv;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    QPainter *painter;
    QImage *frame;
    QImage *frame_gray;
    QTimer *timer;
    int rs; //result
    uchar *pp;
    uchar *p;
    unsigned int len;
    int convert_yuv_to_rgb_pixel(int y, int u, int v);
    int convert_yuv_to_rgb_buffer(unsigned char *yuv, unsigned char *rgb, unsigned int width, unsigned int height);
    VideoDevice *vd;

    // cv realated
    cv::Mat Img;    //orignal image from camera
    cv::Mat ImgPrs; //processed image

private slots:
    void paintEvent(QPaintEvent *);
    void display_error(QString err);
};

#endif // MAINWINDOW_H
